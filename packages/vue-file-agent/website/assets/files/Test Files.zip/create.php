<?php

$extensions = '{"audio":["aif","cda","mid","midi","mp3","mpa","ogg","wav","wma","wpl"],"archive":["7z","arj","deb","pkg","rar","rpm","tar.gz","z","zip"],"disc":["bin","dmg","iso","toast","vcd"],"database":["csv","dat","db","dbf","log","mdb","sav","sql","tar","xml"],"executable":["apk","bat","bin","cgi","pl","com","exe","gadget","jar","py","wsf","ipa"],"font":["fnt","fon","otf","ttf"],"image":["ai","bmp","gif","ico","jpeg","jpg","png","ps","psd","svg","tif","tiff"],"markup":["asp","aspx","cer","cfm","cgi","pl","css","scss","htm","html","js","jsp","vue","part","php","py","rss","xhtml"],"presentation":["key","odp","pps","ppt","pptx"],"script":["c","class","cpp","cs","h","java","sh","swift","vb"],"sheet":["ods","xlr","xls","xlsx"],"system":["bak","cab","cfg","cpl","cur","dll","dmp","drv","icns","ini","lnk","msi","sys","tmp"],"video":["3g2","3gp","avi","flv","h264","m4v","mkv","mov","mp4","mpg","mpeg","rm","swf","vob","wmv"],"doc":["doc","docx","odt","rtf","tex","txt","wks","wps","wpd"],"pdf":["pdf"],"folder":["folder"],"play":["play"]}';


foreach(json_decode($extensions, true) as $category => $extensions){
  file_put_contents(__DIR__.'/file-types/'.$category.'.'.$extensions[0], '');
}